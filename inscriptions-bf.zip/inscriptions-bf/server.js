const express = require("express"), Database = require("better-sqlite3"), multer = require("multer"),
  crypto = require("crypto"), path = require("path"), fs = require("fs"), rateLimit = require("express-rate-limit");

const PW = process.env.ADMIN_PASSWORD, SECRET = process.env.SESSION_SECRET;
if (!PW || !SECRET) { console.error("Définissez ADMIN_PASSWORD et SESSION_SECRET dans .env"); process.exit(1); }

const PIECES = ["Acte de naissance", "Certificat de nationalité", "Bulletins ou relevés de notes",
  "Dernier diplôme ou attestation", "Photo d’identité", "Reçu de paiement"];
const UP = path.join(__dirname, "uploads"); fs.mkdirSync(UP, { recursive: true });

const db = new Database(process.env.DB_PATH || "data.db");
db.pragma("journal_mode = WAL"); db.pragma("foreign_keys = ON");
db.exec(`
create table if not exists etablissements(id integer primary key, nom text not null, ville text);
create table if not exists filieres(id integer primary key, etab_id integer not null references etablissements(id) on delete cascade, nom text not null, frais integer default 0);
create table if not exists inscriptions(id integer primary key, num text unique, nom text, pre text, dn text, sx text, tel text, tel_n text, em text, vi text,
  etab_id integer references etablissements(id), filiere_id integer references filieres(id), ni text, an text, mo integer, pa text, ref text,
  statut text default 'En attente', created text default current_timestamp);
create table if not exists pieces(id integer primary key, insc_id integer not null references inscriptions(id) on delete cascade, type text, fichier text, nom_origine text, unique(insc_id, type));
`);

for (const [c, t] of [["pay_statut", "text default 'À vérifier'"], ["pay_order", "text"], ["pay_token", "text"], ["notif_token", "text"], ["pay_date", "text"], ["relance_n", "integer default 0"], ["relance_at", "text"]])
  if (!db.prepare("select 1 from pragma_table_info('inscriptions') where name=?").get(c)) db.exec(`alter table inscriptions add column ${c} ${t}`);

const ok = { ".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png" };
const upload = multer({
  storage: multer.diskStorage({ destination: UP, filename: (r, f, cb) => cb(null, crypto.randomBytes(16).toString("hex") + path.extname(f.originalname).toLowerCase()) }),
  limits: { fileSize: 5 * 1024 * 1024, files: 6 },
  fileFilter: (r, f, cb) => cb(null, ok[path.extname(f.originalname).toLowerCase()] === f.mimetype)
});
const rm = f => fs.unlink(path.join(UP, f), () => {});
const cut = (v, n = 200) => String(v ?? "").trim().slice(0, n);
const digits = v => String(v ?? "").replace(/\D/g, "");

// ---------- SMS (API Orange « SMS Burkina Faso ») ----------
// Désactivé tant que ORANGE_AUTH_HEADER n’est pas défini dans .env. Un échec d’envoi n’empêche jamais l’inscription.
const SIG = process.env.SMS_SIGNATURE || "Service des inscriptions", SITE = process.env.SITE_URL || "";
let tok = { v: null, exp: 0 };
async function sms(tel, texte) {
  const AUTH = process.env.ORANGE_AUTH_HEADER; if (!AUTH) return;
  let n = digits(tel).replace(/^00/, ""); if (n.length === 8) n = "226" + n;
  if (!/^226\d{8}$/.test(n)) return;
  try {
    if (Date.now() > tok.exp) {
      const r = await fetch("https://api.orange.com/oauth/v3/token", { method: "POST", signal: AbortSignal.timeout(8000),
        headers: { Authorization: AUTH, "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: "grant_type=client_credentials" });
      const j = await r.json(); if (!r.ok) throw new Error("jeton refusé (" + r.status + ")");
      tok = { v: j.access_token, exp: Date.now() + Math.max(60, j.expires_in - 60) * 1000 };
    }
    const req = { address: "tel:+" + n, senderAddress: "tel:+2260000",
      outboundSMSTextMessage: { message: texte.normalize("NFD").replace(/[\u0300-\u036f]/g, "").slice(0, 160) } };
    if (process.env.SMS_SENDER_NAME) req.senderName = process.env.SMS_SENDER_NAME;
    const r = await fetch("https://api.orange.com/smsmessaging/v1/outbound/tel%3A%2B2260000/requests", { method: "POST", signal: AbortSignal.timeout(8000),
      headers: { Authorization: "Bearer " + tok.v, "Content-Type": "application/json" }, body: JSON.stringify({ outboundSMSMessageRequest: req }) });
    if (!r.ok) { if (r.status === 401) tok.exp = 0; console.error("SMS refusé : HTTP", r.status); return false; }
    return true;
  } catch (e) { console.error("SMS échec :", e.message); return false; }
}

const app = express();
if (process.env.TRUST_PROXY) app.set("trust proxy", 1); // à activer (TRUST_PROXY=1) derrière nginx
app.use(express.json({ limit: "20kb" }));
app.use((q, s, n) => { s.set({ "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin" }); n(); });
app.use(express.static(path.join(__dirname, "public")));

const lim = (max) => rateLimit({ windowMs: 15 * 60 * 1000, max, standardHeaders: true, legacyHeaders: false, message: { erreur: "Trop de tentatives, réessayez plus tard." } });

// ---------- Public ----------
app.get("/api/etablissements", (q, s) => {
  const e = db.prepare("select * from etablissements order by nom").all(), f = db.prepare("select * from filieres order by nom").all();
  s.json(e.map(x => ({ ...x, filieres: f.filter(y => y.etab_id === x.id) })));
});

const fields = upload.fields(PIECES.map((_, i) => ({ name: "p" + i, maxCount: 1 })));
app.post("/api/inscriptions", lim(20), fields, (q, s) => {
  const files = Object.values(q.files || {}).flat(), fail = (m) => { files.forEach(f => rm(f.filename)); s.status(400).json({ erreur: m }); };
  const b = q.body, nom = cut(b.nom), pre = cut(b.pre), tel = cut(b.tel, 30);
  if (!nom || !pre || !cut(b.dn) || digits(tel).length < 8) return fail("Nom, prénom, date de naissance et téléphone valides sont obligatoires.");
  if (b.consent !== "oui") return fail("Vous devez accepter la politique de confidentialité.");
  const fi = db.prepare("select * from filieres where id=? and etab_id=?").get(+b.filiere_id, +b.etab_id);
  if (!fi) return fail("Établissement ou filière invalide.");
  const num = `INS-${new Date().getFullYear()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  const tx = db.transaction(() => {
    const id = db.prepare(`insert into inscriptions(num,nom,pre,dn,sx,tel,tel_n,em,vi,etab_id,filiere_id,ni,an,mo,pa,ref) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(num, nom.toUpperCase(), pre, cut(b.dn, 10), cut(b.sx, 20), tel, digits(tel), cut(b.em), cut(b.vi), fi.etab_id, fi.id, cut(b.ni), cut(b.an, 20), fi.frais, cut(b.pa, 40), cut(b.ref, 80)).lastInsertRowid;
    PIECES.forEach((t, i) => { const f = (q.files?.["p" + i] || [])[0]; if (f) db.prepare("insert into pieces(insc_id,type,fichier,nom_origine) values(?,?,?,?)").run(id, t, f.filename, cut(f.originalname)); });
  });
  try { tx(); if (cut(b.pa, 40) === OMON) db.prepare("update inscriptions set pay_statut='À payer' where num=?").run(num); s.status(201).json({ num }); sms(tel, `Inscription recue. N° de dossier : ${num}. Suivi avec ce numero et votre telephone${SITE ? " sur " + SITE : ""}. ${SIG}`); } catch (e) { fail("Erreur d’enregistrement."); }
});

function dossier(num, tel) {
  const d = db.prepare("select * from inscriptions where num=? and tel_n=?").get(cut(num, 30).toUpperCase(), digits(tel));
  if (!d) return null;
  const p = db.prepare("select type from pieces where insc_id=?").all(d.id).map(x => x.type);
  const e = db.prepare("select nom from etablissements where id=?").get(d.etab_id), f = db.prepare("select nom from filieres where id=?").get(d.filiere_id);
  return { num: d.num, nom: d.nom, pre: d.pre, statut: d.statut, paiement: d.pay_statut, enligne: d.pa === OMON && omOn, etab: e?.nom, filiere: f?.nom, ni: d.ni, an: d.an, date: d.created.slice(0, 10), mo: d.mo,
    pieces: PIECES.map(t => ({ type: t, recue: p.includes(t) })) };
}
app.post("/api/suivi", lim(30), async (q, s) => {
  const raw = db.prepare("select * from inscriptions where num=? and tel_n=?").get(cut(q.body.num, 30).toUpperCase(), digits(q.body.tel));
  if (raw) await syncPay(raw);
  const d = dossier(q.body.num, q.body.tel); d ? s.json(d) : s.status(404).json({ erreur: "Aucun dossier ne correspond à ce numéro et à ce téléphone." }); });
app.post("/api/suivi/piece", lim(20), upload.single("fichier"), (q, s) => {
  const f = q.file, fail = m => { if (f) rm(f.filename); s.status(400).json({ erreur: m }); };
  const d = db.prepare("select id from inscriptions where num=? and tel_n=?").get(cut(q.body.num, 30).toUpperCase(), digits(q.body.tel));
  if (!d || !f || !PIECES.includes(q.body.type)) return fail("Requête invalide ou fichier refusé (PDF, JPG ou PNG, 5 Mo max).");
  const old = db.prepare("select fichier from pieces where insc_id=? and type=?").get(d.id, q.body.type);
  db.prepare("insert into pieces(insc_id,type,fichier,nom_origine) values(?,?,?,?) on conflict(insc_id,type) do update set fichier=excluded.fichier, nom_origine=excluded.nom_origine")
    .run(d.id, q.body.type, f.filename, cut(f.originalname));
  if (old) rm(old.fichier);
  s.json({ ok: true });
});

// ---------- Paiement en ligne Orange Money (Web Payment) ----------
// Désactivé tant que OM_AUTH_HEADER, OM_MERCHANT_KEY et SITE_URL ne sont pas tous définis dans .env.
const OMON = "Orange Money (paiement en ligne)";
const OM = { auth: process.env.OM_AUTH_HEADER, key: process.env.OM_MERCHANT_KEY, site: (process.env.SITE_URL || "").replace(/\/$/, ""),
  path: process.env.OM_API_PATH || "/orange-money-webpay/dev/v1", cur: process.env.OM_CURRENCY || "OUV" };
const omOn = !!(OM.auth && OM.key && OM.site);
let omTok = { v: null, exp: 0 };
async function omCall(p, body) {
  if (Date.now() > omTok.exp) {
    const r = await fetch("https://api.orange.com/oauth/v3/token", { method: "POST", signal: AbortSignal.timeout(10000),
      headers: { Authorization: OM.auth, "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: "grant_type=client_credentials" });
    const j = await r.json(); if (!r.ok) throw new Error("jeton refusé (" + r.status + ")");
    omTok = { v: j.access_token, exp: Date.now() + Math.max(60, j.expires_in - 60) * 1000 };
  }
  const r = await fetch("https://api.orange.com" + OM.path + p, { method: "POST", signal: AbortSignal.timeout(15000),
    headers: { Authorization: "Bearer " + omTok.v, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(body) });
  if (r.status === 401) omTok.exp = 0;
  if (!r.ok) throw new Error("Orange Money HTTP " + r.status);
  return r.json();
}
const PAYMAP = { SUCCESS: "Payé", PENDING: "En cours", INITIATED: "En cours", FAILED: "Échec", EXPIRED: "Échec" };
// Seul un statut SUCCESS confirmé par Orange (appel serveur à serveur) marque le dossier comme payé.
async function syncPay(d) {
  if (!omOn || !d.pay_token || !["En cours", "À payer"].includes(d.pay_statut)) return d.pay_statut;
  try {
    const j = await omCall("/transactionstatus", { order_id: d.pay_order, amount: d.mo, pay_token: d.pay_token });
    const st = PAYMAP[j.status] || d.pay_statut;
    if (st !== d.pay_statut) db.prepare("update inscriptions set pay_statut=? where id=? and pay_statut<>'Payé'").run(st, d.id);
    if (st === "Payé") db.prepare("update inscriptions set pay_date=date('now') where id=? and pay_date is null").run(d.id);
    return st;
  } catch (e) { console.error("Paiement : vérification impossible :", e.message); return d.pay_statut; }
}
app.get("/api/config", (q, s) => s.json({ omEnabled: omOn, omLabel: OMON }));
app.post("/api/paiement/orange", lim(20), async (q, s) => {
  if (!omOn) return s.status(503).json({ erreur: "Le paiement en ligne n’est pas activé." });
  const d = db.prepare("select * from inscriptions where num=? and tel_n=?").get(cut(q.body.num, 30).toUpperCase(), digits(q.body.tel));
  if (!d) return s.status(404).json({ erreur: "Dossier introuvable." });
  if (d.pay_statut === "Payé") return s.status(400).json({ erreur: "Ce dossier est déjà payé." });
  if (!(d.mo > 0)) return s.status(400).json({ erreur: "Aucun montant à payer." });
  try {
    const order = d.num + "-" + crypto.randomBytes(2).toString("hex");
    const j = await omCall("/webpayment", { merchant_key: OM.key, currency: OM.cur, order_id: order, amount: d.mo, lang: "fr", reference: d.num,
      return_url: `${OM.site}/?retour=${d.num}`, cancel_url: `${OM.site}/?annule=${d.num}`, notif_url: `${OM.site}/api/paiement/notif` });
    if (!j.pay_token || new URL(j.payment_url).protocol !== "https:") throw new Error("réponse inattendue");
    db.prepare("update inscriptions set pay_order=?, pay_token=?, notif_token=?, pay_statut='En cours', pa=? where id=?").run(order, j.pay_token, j.notif_token || null, OMON, d.id);
    s.json({ payment_url: j.payment_url });
  } catch (e) { console.error("Paiement : création impossible :", e.message); s.status(502).json({ erreur: "Le paiement en ligne est momentanément indisponible. Réessayez plus tard depuis « Suivi de dossier »." }); }
});
// Orange ne signe pas ses notifications : on retrouve le dossier par notif_token, puis on revérifie auprès d'Orange.
app.post("/api/paiement/notif", lim(300), async (q, s) => {
  const t = cut(q.body?.notif_token, 100), d = t && db.prepare("select * from inscriptions where notif_token=?").get(t);
  s.sendStatus(200);
  if (d) await syncPay(d);
});

// ---------- Relance SMS des paiements en ligne non terminés ----------
// Toutes les heures : rappelle (max RELANCE_MAX fois, espacées de RELANCE_HEURES) les candidats dont le paiement Orange Money n'est pas abouti.
const REL_H = +process.env.RELANCE_HEURES || 24, REL_MAX = process.env.RELANCE_MAX === undefined ? 2 : +process.env.RELANCE_MAX;
async function relances() {
  if (!process.env.ORANGE_AUTH_HEADER || !omOn || !(REL_MAX > 0)) return;
  const age = `-${REL_H} hours`;
  const rows = db.prepare(`select * from inscriptions where pa=? and pay_statut in ('À payer','En cours','Échec') and statut<>'Rejetée'
    and relance_n<? and created < datetime('now', ?) and (relance_at is null or relance_at < datetime('now', ?)) limit 20`).all(OMON, REL_MAX, age, age);
  for (const d of rows) {
    if ((await syncPay(d)) === "Payé") continue; // déjà payé : pas de relance
    const sent = await sms(d.tel, `Dossier ${d.num} : paiement non termine. Reprenez-le dans Suivi de dossier : ${OM.site}. ${SIG}`);
    db.prepare("update inscriptions set relance_n=relance_n+?, relance_at=datetime('now') where id=?").run(sent ? 1 : 0, d.id);
  }
}
const lancer = () => relances().catch(e => console.error("Relances :", e.message));
setTimeout(lancer, 60 * 1000).unref(); setInterval(lancer, 3600 * 1000).unref();

// ---------- Reçu de paiement (page imprimable /recu.html) ----------
const EMET = process.env.RECU_EMETTEUR || SIG;
function recu(d) {
  const e = db.prepare("select nom,ville from etablissements where id=?").get(d.etab_id), f = db.prepare("select nom from filieres where id=?").get(d.filiere_id);
  return { recu: "REC-" + d.num, num: d.num, nom: d.nom, pre: d.pre, etab: e?.nom, ville: e?.ville, filiere: f?.nom, ni: d.ni, an: d.an, mo: d.mo, pa: d.pa, ref: d.ref,
    date: d.pay_date || d.created.slice(0, 10), emetteur: EMET };
}
app.post("/api/recu", lim(30), async (q, s) => {
  const d = db.prepare("select * from inscriptions where num=? and tel_n=?").get(cut(q.body.num, 30).toUpperCase(), digits(q.body.tel));
  if (!d) return s.status(404).json({ erreur: "Aucun dossier ne correspond à ce numéro et à ce téléphone." });
  await syncPay(d);
  const x = db.prepare("select * from inscriptions where id=?").get(d.id);
  if (x.pay_statut !== "Payé") return s.status(409).json({ erreur: "Aucun paiement confirmé pour ce dossier : le reçu n’est pas disponible." });
  s.json(recu(x));
});

// ---------- Administration ----------
db.exec("create table if not exists admins(id integer primary key, login text unique not null, hash text not null, role text not null default 'agent', created text default current_timestamp)");
const sign = v => crypto.createHmac("sha256", SECRET).update(v).digest("hex");
const hash = (pw, salt = crypto.randomBytes(16).toString("hex")) => `${salt}:${crypto.scryptSync(pw, salt, 64).toString("hex")}`;
const check = (pw, h) => { const [salt, k] = String(h).split(":"); if (!salt || !k) return false; const a = crypto.scryptSync(pw, salt, 64), b = Buffer.from(k, "hex"); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const DUMMY = hash("x");
// Premier démarrage : le compte « admin » (super-administrateur) est créé avec ADMIN_PASSWORD.
if (!db.prepare("select 1 from admins").get()) db.prepare("insert into admins(login,hash,role) values(?,?,?)").run("admin", hash(PW), "super");
const cookie = (q, k) => (q.headers.cookie || "").split(/;\s*/).map(c => c.split("=")).find(c => c[0] === k)?.[1];
function auth(q, s, n) {
  const [id, exp, sig] = (cookie(q, "adm") || "..").split(".");
  const ok = sig && sig.length === 64 && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(sign(id + "." + exp))) && +exp > Date.now();
  const a = ok && db.prepare("select id,login,role from admins where id=?").get(+id);
  if (!a) return s.status(401).json({ erreur: "Non autorisé" });
  q.admin = a; n();
}
const sup = (q, s, n) => q.admin.role === "super" ? n() : s.status(403).json({ erreur: "Réservé au super-administrateur." });
app.post("/api/admin/login", lim(10), (q, s) => {
  const a = db.prepare("select * from admins where login=?").get(cut(q.body.login, 50).toLowerCase());
  const good = check(String(q.body.mdp ?? ""), a ? a.hash : DUMMY) && a;
  if (!good) return s.status(401).json({ erreur: "Identifiant ou mot de passe incorrect." });
  const v = `${a.id}.${Date.now() + 8 * 3600 * 1000}`;
  s.set("Set-Cookie", `adm=${v}.${sign(v)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${process.env.NODE_ENV === "production" ? "; Secure" : ""}`).json({ role: a.role, login: a.login });
});
app.post("/api/admin/logout", (q, s) => s.set("Set-Cookie", "adm=; Path=/; Max-Age=0").json({ ok: true }));
app.get("/api/admin/moi", auth, (q, s) => s.json(q.admin));
app.get("/api/admin/comptes", auth, sup, (q, s) => s.json(db.prepare("select id,login,role,created from admins order by id").all()));
app.post("/api/admin/comptes", auth, sup, (q, s) => {
  const login = cut(q.body.login, 50).toLowerCase(), mdp = String(q.body.mdp ?? ""), role = q.body.role === "super" ? "super" : "agent";
  if (!/^[a-z0-9._-]{3,50}$/.test(login) || mdp.length < 10) return s.status(400).json({ erreur: "Identifiant (3 à 50 caractères : lettres, chiffres, . _ -) et mot de passe d’au moins 10 caractères requis." });
  try { db.prepare("insert into admins(login,hash,role) values(?,?,?)").run(login, hash(mdp), role); s.json({ ok: true }); }
  catch (e) { s.status(409).json({ erreur: "Cet identifiant existe déjà." }); }
});
app.delete("/api/admin/comptes/:id", auth, sup, (q, s) => {
  if (+q.params.id === q.admin.id) return s.status(400).json({ erreur: "Vous ne pouvez pas supprimer votre propre compte." });
  db.prepare("delete from admins where id=?").run(+q.params.id); s.json({ ok: true });
});
app.post("/api/admin/mdp", auth, lim(10), (q, s) => {
  const a = db.prepare("select * from admins where id=?").get(q.admin.id), n = String(q.body.nouveau ?? "");
  if (!check(String(q.body.ancien ?? ""), a.hash) || n.length < 10) return s.status(400).json({ erreur: "Ancien mot de passe incorrect, ou nouveau mot de passe trop court (10 caractères minimum)." });
  db.prepare("update admins set hash=? where id=?").run(hash(n), a.id); s.json({ ok: true });
});
app.get("/api/admin/inscriptions", auth, (q, s) => {
  const r = db.prepare(`select i.*, e.nom as etab, f.nom as filiere from inscriptions i left join etablissements e on e.id=i.etab_id left join filieres f on f.id=i.filiere_id order by i.id desc`).all();
  const p = db.prepare("select id, insc_id, type from pieces").all();
  s.json(r.map(x => ({ ...x, tel_n: undefined, pay_token: undefined, notif_token: undefined, pay_order: undefined, pieces: p.filter(y => y.insc_id === x.id) })));
});
app.post("/api/admin/inscriptions/:id/statut", auth, (q, s) => {
  if (!["En attente", "Validée", "Rejetée"].includes(q.body.statut)) return s.status(400).json({ erreur: "Statut invalide" });
  const d = db.prepare("select num,tel,statut from inscriptions where id=?").get(+q.params.id);
  if (!d) return s.sendStatus(404);
  db.prepare("update inscriptions set statut=? where id=?").run(q.body.statut, +q.params.id); s.json({ ok: true });
  if (d.statut !== q.body.statut && q.body.statut !== "En attente")
    sms(d.tel, `Dossier ${d.num} : inscription ${q.body.statut === "Validée" ? "validee" : "rejetee"}. Details dans le suivi de dossier${SITE ? " : " + SITE : ""}. ${SIG}`);
});
// ---------- Durée de conservation : liste, export et purge des dossiers expirés ----------
// RETENTION_MOIS=0 (défaut) : rien n'expire. PURGE_AUTO=1 : suppression automatique quotidienne (sans archive : l'objectif est d'effacer).
const RET = +process.env.RETENTION_MOIS || 0, PURGE_AUTO = process.env.PURGE_AUTO === "1";
const perimes = () => RET > 0 ? db.prepare(`select i.*, e.nom as etab, f.nom as filiere from inscriptions i left join etablissements e on e.id=i.etab_id
  left join filieres f on f.id=i.filiere_id where i.created < datetime('now', ?) order by i.id`).all(`-${RET} months`) : [];
function purger(rows) {
  for (const d of rows) {
    db.prepare("select fichier from pieces where insc_id=?").all(d.id).forEach(x => rm(x.fichier));
    db.prepare("delete from inscriptions where id=?").run(d.id);
  }
  return rows.length;
}
const csvCell = v => { let t = String(v ?? ""); if (/^[=+\-@]/.test(t)) t = "'" + t; return '"' + t.replace(/"/g, '""') + '"'; }; // anti-injection de formules
// ---------- Apparence : titre, logo et bannière ----------
db.exec("create table if not exists reglages(cle text primary key, valeur text)");
const MEDIA = path.join(__dirname, "media"); fs.mkdirSync(MEDIA, { recursive: true });
app.use("/media", express.static(MEDIA, { maxAge: "1h", dotfiles: "ignore", setHeaders: r => r.setHeader("Content-Security-Policy", "default-src 'none'") }));
const upImg = multer({
  storage: multer.diskStorage({ destination: MEDIA, filename: (r, f, cb) => cb(null, crypto.randomBytes(8).toString("hex") + path.extname(f.originalname).toLowerCase()) }),
  limits: { fileSize: 3 * 1024 * 1024, files: 2 },
  fileFilter: (r, f, cb) => cb(null, [".png", ".jpg", ".jpeg", ".webp"].includes(path.extname(f.originalname).toLowerCase()) && /^image\/(png|jpeg|webp)$/.test(f.mimetype))
}).fields([{ name: "logo", maxCount: 1 }, { name: "banniere", maxCount: 1 }]);
const imgs = (q, s, n) => upImg(q, s, e => e ? s.status(400).json({ erreur: "Image refusée (PNG, JPG ou WebP, 3 Mo maximum)." }) : n());
const reg = k => db.prepare("select valeur from reglages where cle=?").get(k)?.valeur || "";
const setReg = (k, v) => db.prepare("insert into reglages(cle,valeur) values(?,?) on conflict(cle) do update set valeur=excluded.valeur").run(k, v);
const delMedia = f => f && fs.unlink(path.join(MEDIA, path.basename(f)), () => {});
app.get("/api/apparence", (q, s) => s.json({ titre: reg("titre"), sous: reg("sous"), logo: reg("logo") && "/media/" + reg("logo"), banniere: reg("banniere") && "/media/" + reg("banniere") }));
app.post("/api/admin/apparence", auth, sup, imgs, (q, s) => {
  const b = q.body, f = q.files || {};
  if (b.titre !== undefined) setReg("titre", cut(b.titre, 80));
  if (b.sous !== undefined) setReg("sous", cut(b.sous, 160));
  for (const k of ["logo", "banniere"]) {
    const nf = f[k]?.[0];
    if (nf || b["retirer_" + k]) { delMedia(reg(k)); setReg(k, nf ? nf.filename : ""); }
  }
  s.json({ ok: true });
});

app.get("/api/admin/purge", auth, sup, (q, s) => {
  const r = perimes();
  s.json({ mois: RET, auto: PURGE_AUTO, total: r.length, dossiers: r.slice(0, 5).map(d => ({ num: d.num })) });
});
app.get("/api/admin/purge/export", auth, sup, (q, s) => {
  const h = ["num", "nom", "pre", "dn", "sx", "tel", "em", "vi", "etab", "filiere", "ni", "an", "mo", "pa", "pay_statut", "pay_date", "ref", "statut", "created"];
  const lignes = [h.join(";")].concat(perimes().map(d => h.map(k => csvCell(d[k])).join(";")));
  s.set({ "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="dossiers-a-supprimer.csv"' }).send("\ufeff" + lignes.join("\n"));
});
app.post("/api/admin/purge", auth, sup, (q, s) => {
  if (!(RET > 0)) return s.status(400).json({ erreur: "Durée de conservation non définie (RETENTION_MOIS)." });
  if (q.body.confirmation !== "SUPPRIMER") return s.status(400).json({ erreur: "Confirmation manquante." });
  s.json({ supprimes: purger(perimes()) });
});
const purgeAuto = () => { try { if (PURGE_AUTO && RET > 0) { const n = purger(perimes()); if (n) console.log(`Purge automatique : ${n} dossier(s) supprimé(s).`); } } catch (e) { console.error("Purge :", e.message); } };
setTimeout(purgeAuto, 5 * 60 * 1000).unref(); setInterval(purgeAuto, 24 * 3600 * 1000).unref();

app.get("/api/admin/recu/:id", auth, (q, s) => {
  const d = db.prepare("select * from inscriptions where id=?").get(+q.params.id);
  if (!d) return s.sendStatus(404);
  if (d.pay_statut !== "Payé") return s.status(409).json({ erreur: "Paiement non marqué comme payé : pas de reçu." });
  s.json(recu(d));
});
app.post("/api/admin/inscriptions/:id/paiement", auth, (q, s) => {
  if (!["Payé", "À vérifier"].includes(q.body.pay_statut)) return s.status(400).json({ erreur: "Valeur invalide" });
  db.prepare("update inscriptions set pay_statut=? where id=?").run(q.body.pay_statut, +q.params.id);
  if (q.body.pay_statut === "Payé") db.prepare("update inscriptions set pay_date=date('now') where id=? and pay_date is null").run(+q.params.id);
  else db.prepare("update inscriptions set pay_date=null where id=?").run(+q.params.id);
  s.json({ ok: true });
});
app.delete("/api/admin/inscriptions/:id", auth, sup, (q, s) => {
  db.prepare("select fichier from pieces where insc_id=?").all(+q.params.id).forEach(x => rm(x.fichier));
  db.prepare("delete from inscriptions where id=?").run(+q.params.id); s.json({ ok: true });
});
app.get("/api/admin/pieces/:id", auth, (q, s) => {
  const p = db.prepare("select * from pieces where id=?").get(+q.params.id);
  p ? s.download(path.join(UP, p.fichier), p.nom_origine) : s.sendStatus(404);
});
app.post("/api/admin/etablissements", auth, sup, (q, s) => {
  const nom = cut(q.body.nom), fil = cut(q.body.filiere);
  if (!nom || !fil) return s.status(400).json({ erreur: "Établissement et filière obligatoires." });
  let e = db.prepare("select id from etablissements where nom=?").get(nom);
  if (!e) e = { id: db.prepare("insert into etablissements(nom,ville) values(?,?)").run(nom, cut(q.body.ville)).lastInsertRowid };
  db.prepare("insert into filieres(etab_id,nom,frais) values(?,?,?)").run(e.id, fil, Math.max(0, +q.body.frais || 0)); s.json({ ok: true });
});
app.delete("/api/admin/filieres/:id", auth, sup, (q, s) => {
  try {
    const f = db.prepare("select etab_id from filieres where id=?").get(+q.params.id);
    db.prepare("delete from filieres where id=?").run(+q.params.id);
    if (f && !db.prepare("select 1 from filieres where etab_id=?").get(f.etab_id)) db.prepare("delete from etablissements where id=?").run(f.etab_id);
    s.json({ ok: true });
  } catch (e) { s.status(409).json({ erreur: "Des inscriptions utilisent cette filière : impossible de la supprimer." }); }
});

app.listen(process.env.PORT || 3000, () => console.log("Site disponible sur http://localhost:" + (process.env.PORT || 3000)));
