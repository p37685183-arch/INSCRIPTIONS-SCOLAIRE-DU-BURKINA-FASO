# Guide de mise en ligne sur un serveur (VPS) – pas à pas

Ce guide suppose un serveur **Ubuntu 24.04 LTS** (ou 22.04) et un **nom de domaine** que vous contrôlez. Comptez 1 à 2 heures la première fois. Remplacez `votre-domaine.bf` par votre vrai domaine.

## 0. Avant de commencer
- **VPS** : 1 vCPU, 1 à 2 Go de RAM, 20 Go de disque suffisent pour démarrer. Prévoyez de la place pour les pièces jointes (comptez environ 5 à 15 Mo par dossier au maximum).
- **Domaine** : créez un enregistrement DNS de type **A** qui pointe `votre-domaine.bf` vers l’adresse IP du serveur. Attendez que la propagation soit faite (de quelques minutes à quelques heures) avant l’étape 7.
- **Accès** : une clé SSH est préférable à un mot de passe.

## 1. Se connecter et sécuriser le serveur
```bash
ssh root@ADRESSE_IP
adduser app                      # créez un utilisateur normal
usermod -aG sudo app
rsync --archive --chown=app:app ~/.ssh /home/app   # copie votre clé SSH
ufw allow OpenSSH && ufw allow 80 && ufw allow 443 && ufw enable
apt update && apt -y upgrade && apt -y install unattended-upgrades
exit
ssh app@ADRESSE_IP               # travaillez désormais avec cet utilisateur
```
Désactivez ensuite la connexion SSH par mot de passe (`PasswordAuthentication no` dans `/etc/ssh/sshd_config`, puis `sudo systemctl restart ssh`) une fois que votre clé fonctionne.

## 2. Installer Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt -y install nodejs build-essential python3
node -v        # doit afficher v22.x
```

## 3. Envoyer le projet sur le serveur
Depuis votre ordinateur :
```bash
scp inscriptions-bf.zip app@ADRESSE_IP:~
```
Puis sur le serveur :
```bash
sudo apt -y install unzip
unzip inscriptions-bf.zip && cd inscriptions-bf
npm install --omit=dev
```

## 4. Configurer
```bash
cp .env.example .env
chmod 600 .env                   # seul vous pouvez lire ce fichier
openssl rand -hex 32             # génère une chaîne pour SESSION_SECRET
nano .env
```
À renseigner au minimum : `ADMIN_PASSWORD` (long et unique), `SESSION_SECRET` (la chaîne générée), `SITE_URL=https://votre-domaine.bf`. Laissez vides pour l’instant les clés Orange (SMS et paiement) : activez-les après les premiers tests.

Test rapide : `npm start` doit afficher « Site disponible sur http://localhost:3000 ». Arrêtez avec Ctrl+C.

## 5. Lancer en continu avec pm2
```bash
sudo npm install -g pm2
pm2 start npm --name inscriptions -- start
pm2 save
pm2 startup                      # exécutez la commande qu’il affiche
```
Le site redémarre alors tout seul après un redémarrage du serveur. Journaux : `pm2 logs inscriptions`.

## 6. Installer nginx
```bash
sudo apt -y install nginx
sudo nano /etc/nginx/sites-available/inscriptions
```
Contenu :
```nginx
server {
    listen 80;
    server_name votre-domaine.bf;
    client_max_body_size 30m;     # 6 pièces de 5 Mo maximum
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/inscriptions /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

## 7. Activer HTTPS (obligatoire)
```bash
sudo apt -y install certbot python3-certbot-nginx
sudo certbot --nginx -d votre-domaine.bf
```
Répondez aux questions (acceptez la redirection HTTP vers HTTPS). Le renouvellement est automatique ; vérifiez-le avec `sudo certbot renew --dry-run`. Ouvrez ensuite https://votre-domaine.bf : le formulaire doit s’afficher avec le cadenas.

## 8. Premier accès administrateur
1. Allez sur `https://votre-domaine.bf/admin.html` et connectez-vous avec l’identifiant `admin` et la valeur de `ADMIN_PASSWORD`.
2. Onglet « Comptes » : changez ce mot de passe, puis créez un compte par collaborateur (rôle « agent » pour ceux qui valident les dossiers).
3. Onglet « Établissements et filières » : saisissez vos établissements, leurs filières et leurs frais.

## 9. Sauvegardes (ne sautez pas cette étape)
```bash
sudo apt -y install sqlite3
mkdir -p ~/backups
crontab -e
```
Ajoutez (les `\%` sont nécessaires dans crontab) :
```cron
0 2 * * * sqlite3 /home/app/inscriptions-bf/data.db ".backup '/home/app/backups/data-$(date +\%F).db'" && tar -czf /home/app/backups/uploads-$(date +\%F).tgz -C /home/app/inscriptions-bf uploads media && find /home/app/backups -mtime +14 -delete
```
Une sauvegarde qui reste sur le même serveur ne protège pas d’une panne du serveur : copiez-la régulièrement ailleurs (autre serveur, disque externe, stockage en ligne). **Essayez une restauration** au moins une fois (copier `data.db` et `uploads/` sur une machine de test) pour être sûr que ça marche.

## 10. Activer SMS et paiement Orange Money
Une fois le site stable en HTTPS, suivez les sections « Notifications SMS » et « Paiement en ligne Orange Money » du README, remplissez les variables dans `.env`, puis `pm2 restart inscriptions`. Orange doit pouvoir joindre `https://votre-domaine.bf/api/paiement/notif` : le site doit être public.

## 11. Mettre à jour le site
Envoyez la nouvelle version, décompressez-la **sans écraser** `.env`, `data.db*` et `uploads/`, puis :
```bash
cd ~/inscriptions-bf && npm install --omit=dev && pm2 restart inscriptions
```

## 12. Liste de contrôle avant l’ouverture au public
- [ ] Inscription complète testée depuis un téléphone (avec pièces jointes), puis visible dans l’administration.
- [ ] Suivi de dossier, validation/rejet et reçu testés.
- [ ] SMS testé avec un numéro Orange **et** un numéro d’un autre opérateur.
- [ ] Paiement Orange Money testé en sandbox, puis avec un vrai petit montant en production (valeurs `OM_API_PATH` et `OM_CURRENCY` fournies par Orange).
- [ ] Mot de passe `admin` changé, comptes nominatifs créés, `.env` en `chmod 600`.
- [ ] HTTPS actif, sauvegarde automatique en place et restauration essayée.
- [ ] Informations légales : `public/confidentialite.html` complétée (`grep -c "<mark>" public/confidentialite.html` affiche 0) et validée par un juriste ; vérification de vos obligations (CIL, loi sur la protection des données personnelles).
- [ ] Ouverture progressive (quelques candidats d’abord), avec une personne qui surveille `pm2 logs inscriptions`.

## Dépannage
| Symptôme | Piste |
|---|---|
| Page blanche ou « 502 Bad Gateway » | Le site est arrêté : `pm2 status`, `pm2 logs inscriptions`. |
| « 413 Request Entity Too Large » à l’envoi des pièces | Augmentez `client_max_body_size` dans nginx, puis `sudo systemctl reload nginx`. |
| Message « Trop de tentatives » pour tout le monde | `TRUST_PROXY=1` manque dans `.env` (le serveur voit alors l’adresse de nginx pour tous). |
| Le certificat HTTPS échoue | Le DNS ne pointe pas encore vers le serveur, ou le port 80 est fermé (`sudo ufw status`). |
| Pas de SMS | `pm2 logs inscriptions` (lignes « SMS refusé » ou « SMS échec »), forfait Orange épuisé, clé mal copiée. |
| Paiement bloqué « En cours » | Orange n’a pas joint `/api/paiement/notif` (site non public ?) : le statut se met aussi à jour quand le candidat ouvre « Suivi de dossier ». |
