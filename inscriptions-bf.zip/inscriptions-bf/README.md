# Site public d’inscriptions – Burkina Faso

Site ouvert à tous les candidats, sans compte : inscription, pièces jointes, consultation des filières et suivi de dossier (numéro + téléphone). Espace administrateur sur `/admin.html`.

## Comptes administrateurs
Au premier démarrage, le compte `admin` (super-administrateur) est créé avec la valeur `ADMIN_PASSWORD`. Connectez-vous, puis créez les comptes de vos collaborateurs dans l’onglet « Comptes » et changez le mot de passe de `admin`. Le super-administrateur gère comptes, établissements, filières et suppressions ; l’agent consulte, valide et rejette les dossiers. `ADMIN_PASSWORD` n’est plus utilisé ensuite.

## Démarrage local
1. Installer Node.js 20.6 ou plus récent.
2. `cp .env.example .env`, puis choisir `ADMIN_PASSWORD` (long et unique) et `SESSION_SECRET` (chaîne aléatoire).
3. `npm install` puis `npm start`.
4. Ouvrir http://localhost:3000, puis http://localhost:3000/admin.html pour ajouter vos établissements et filières.

## Notifications SMS (Orange Burkina Faso)
Le site envoie un SMS à la confirmation d’inscription, puis quand un dossier est validé ou rejeté.
1. Créez un compte sur developer.orange.com, souscrivez à l’API « SMS Burkina Faso » et achetez un forfait de SMS (voir la page tarifs de l’API).
2. Dans « My Apps » > Credentials, copiez l’en-tête d’autorisation complet (`Basic …`) dans `ORANGE_AUTH_HEADER` (fichier `.env`), puis renseignez `SMS_SIGNATURE` et `SITE_URL`.
3. Redémarrez le site. Sans `ORANGE_AUTH_HEADER`, les SMS sont simplement désactivés.

À savoir : d’après sa description, cette API s’adresse aux abonnés Orange ; testez avec des numéros d’autres opérateurs avant de compter dessus. Les conditions d’Orange demandent de signer chaque SMS (c’est le rôle de `SMS_SIGNATURE`) et de ne pas y faire référence à Orange. Les SMS sont envoyés sans accents et limités à 160 caractères. Un forfait épuisé ou expiré fait échouer l’envoi du SMS, mais pas l’inscription (voir les journaux du serveur).

## Paiement en ligne Orange Money
Option « Orange Money (paiement en ligne) » : après l’inscription, le candidat est redirigé vers la page sécurisée d’Orange, puis revient sur le site. Le dossier passe à « Payé » uniquement lorsque le serveur a vérifié le paiement auprès d’Orange. Le montant est celui de la filière, fixé côté serveur. Un candidat dont le paiement a échoué peut réessayer depuis « Suivi de dossier ».

**Prérequis (côté Orange)** : être commerçant Orange Money (contrat et compte marchand auprès d’Orange Burkina Faso), puis souscrire l’API Orange Money Web Payment dans votre application sur developer.orange.com. Vous obtenez une clé marchand (`merchant key`) et l’en-tête d’autorisation de l’application.
1. Renseignez `OM_AUTH_HEADER`, `OM_MERCHANT_KEY` et `SITE_URL` (adresse publique en **https**, car Orange doit pouvoir appeler `/api/paiement/notif`).
2. Testez d’abord en sandbox (valeurs par défaut de `OM_API_PATH` et `OM_CURRENCY`).
3. Pour la production, remplacez `OM_API_PATH` et `OM_CURRENCY` par les valeurs que vous donne Orange pour le Burkina Faso. **Ne passez pas en production sans avoir réalisé des paiements de test réels de bout en bout.**

Les autres modes (Moov Money, Coris Money, espèces, virement, transfert Orange Money manuel) restent à vérifier à la main : un administrateur clique sur « Payé » dans l’espace d’administration après contrôle. Moov Money n’a pas d’intégration en ligne ici.

## Couleurs
Le thème est bleu. Les couleurs se changent en haut de `public/style.css` : `--pr` (couleur principale), `--rd` et `--ye` (dégradé et accents), avec une deuxième série de valeurs pour le mode sombre juste en dessous. Les couleurs de statut (vert, jaune, rouge pour validé, en attente, rejeté) sont volontairement conservées.

## Polices
Les titres utilisent une police à empattements (Georgia, ou l’équivalent disponible sur l’appareil) et le texte la police moderne du système. Aucune police n’est téléchargée depuis Internet : le site reste rapide et ne transmet aucune donnée à un tiers. Le rendu peut varier légèrement d’un appareil à l’autre. Pour changer de police, modifiez `--police-titre` (titres) ou la ligne `font:` de `body` (texte) dans `public/style.css`. Pour imposer une police précise identique partout, hébergez vous-même ses fichiers `.woff2` dans `public/fonts/` et déclarez-les avec `@font-face`.

## Logo, bannière et titre
Dans l’administration, onglet « Comptes » (super-administrateur), bloc « Apparence du site » : changez le titre et le sous-titre, envoyez un **logo** (affiché dans l’en-tête et sur les reçus) et une **bannière** large (par exemple 1600 × 400 px) au format PNG, JPG ou WebP, 3 Mo maximum. Les images sont enregistrées dans le dossier `media/` (à sauvegarder avec `uploads/`). Les images SVG sont refusées par prudence. Prenez des images dont vous détenez les droits.

## Durée de conservation et suppression
Réglez `RETENTION_MOIS` dans `.env` (par exemple 24) : les dossiers plus anciens sont alors « expirés ». Dans l’administration, onglet « Comptes » (super-administrateur) : bloc « Conservation des données » avec le nombre de dossiers expirés, le **téléchargement de leur liste en CSV** puis leur **suppression définitive** (dossiers et pièces jointes, confirmation en tapant SUPPRIMER). Avec `PURGE_AUTO=1`, la suppression se fait automatiquement chaque jour, **sans archive** (l’objectif étant d’effacer) : activez-la seulement quand votre politique est claire. Le CSV ne contient pas les pièces jointes ; sauvegardez `uploads/` si vous devez les garder. Les sauvegardes du guide de déploiement sont effacées après 14 jours, ce qui est indiqué dans la politique de confidentialité ; adaptez les deux ensemble si vous changez ce délai.

## Politique de confidentialité
`public/confidentialite.html` est un **modèle** adapté aux données réellement collectées par ce site. Avant la mise en ligne : remplacez tous les passages surlignés en jaune (nom de l’organisme, contacts, hébergeur, durées de conservation…), puis faites valider le texte par un juriste. Contrôle : `grep -c "<mark>" public/confidentialite.html` doit afficher `0`. Le formulaire exige que le candidat coche l’acceptation (vérifiée aussi côté serveur) et le pied de page renvoie vers cette politique. Le site ne supprime pas automatiquement les anciens dossiers : un super-administrateur peut les supprimer (bouton « Suppr. », pièces comprises), à faire selon la durée de conservation que vous annoncez.

## Relance SMS des paiements non terminés
Toutes les heures, le serveur repère les dossiers dont le paiement Orange Money en ligne n’a pas abouti (jamais lancé, en cours ou échoué) et envoie un SMS de rappel : 24 h après l’inscription, puis 24 h plus tard, au maximum 2 relances (`RELANCE_HEURES`, `RELANCE_MAX`). Avant chaque relance, le paiement est revérifié auprès d’Orange pour ne jamais relancer quelqu’un qui a déjà payé. Un SMS qui échoue (forfait épuisé…) ne compte pas comme relance et sera retenté plus tard. Les dossiers rejetés et les autres modes de paiement ne sont pas relancés. Fonctionne seulement si les SMS Orange et le paiement Orange Money sont configurés.

## Reçu de paiement
Quand un dossier est « Payé », le candidat (depuis « Suivi de dossier ») et l’administrateur (bouton « Reçu » dans la liste) ouvrent une page de reçu prête à imprimer (`/recu.html`). Le bouton « Imprimer / enregistrer en PDF » ouvre la boîte d’impression du navigateur : choisissez « Enregistrer au format PDF » (ordinateur, Android et iPhone). Le reçu n’est délivré que si le paiement est confirmé (Orange Money vérifié auprès d’Orange, ou marqué « Payé » par un administrateur) et il porte la date de confirmation. Personnalisez l’émetteur avec `RECU_EMETTEUR`.

## Mise en ligne (serveur VPS)
Guide pas à pas complet : voir **DEPLOIEMENT.md**.
- Mettre `NODE_ENV=production`, mettre `TRUST_PROXY=1` dans `.env` et placer le site derrière nginx ou Caddy avec **HTTPS** (Let’s Encrypt). Sans HTTPS, les données personnelles et le mot de passe circulent en clair.
- Lancer avec pm2 (`pm2 start npm -- start`) pour le redémarrage automatique.
- **Sauvegardes** : copier régulièrement `data.db` (et ses fichiers `-wal`/`-shm`) et le dossier `uploads/`.
- Les pièces sont dans `uploads/`, hors du dossier public ; elles ne sont téléchargeables que par l’administrateur connecté.

## Sécurité en place
Comptes administrateurs individuels (mots de passe hachés avec scrypt), rôles « super-administrateur » et « agent », cookie HttpOnly signé (8 h), limitation du nombre de tentatives, fichiers limités à PDF/JPG/PNG de 5 Mo avec noms aléatoires, montant des frais recalculé côté serveur, requêtes SQL paramétrées, affichage échappé.

## Limites connues (à traiter avant un usage à grande échelle)
- Paiement en ligne uniquement pour Orange Money (et seulement après contrat marchand) ; pas de remboursement ni de reçu automatique dans l’application.
- Pas de notification par e-mail.
- Le numéro de dossier + le téléphone servent de preuve d’identité pour le suivi.
- Données personnelles (y compris de mineurs) : vérifiez vos obligations légales au Burkina Faso (loi sur la protection des données personnelles, déclaration ou autorisation auprès de la CIL) et informez les candidats de l’usage de leurs données.
